﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fibonnaci
{
    class Program
    {
        static void Main(string[] args)
        {
            int n, i, a = 0, b = 1, c;
            Console.WriteLine("Enter n :");
            n = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("For Loop :");
            for (i = a; i <= n; i++)
            {
                Console.Write(a +" , ");
                c = a + b;
                a = b;
                b = c;
            }
            Console.WriteLine();
            Console.WriteLine("While Loop :");
            a = 0; b = 1; i = a;
             
            while(i<=n)
            {
                Console.Write(a +" , ");
                c = a + b;
                a = b;
                b = c;
                i++;
            }

            Console.WriteLine();
            Console.WriteLine("Do..While Loop :");
            a = 0; b = 1; i = a;
            do
            {
                Console.Write(a + " , ");
                c = a + b;
                a = b;
                b = c;
                i++;
            } while (i <= n);
            Console.Read();
        }
    }
}
