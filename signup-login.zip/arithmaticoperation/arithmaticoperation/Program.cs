﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace arithmaticoperation
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Clear;
            int a, b, c;
            Console.Write("enter A:");
            a = Convert.ToInt32(Console.ReadLine());
            Console.Write("enter b:");
            b= Convert.ToInt32(Console.ReadLine());

    if(a = b)
            {
                Console.WriteLine(" a is equal b:");
           }

        }
    }
}
