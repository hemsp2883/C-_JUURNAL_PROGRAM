﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace while1
{
    class Program
    {
        static void Main(string[] args)
        {
            int i=1, j;
            while (i <= 5)
            {
                j = 1;
                while (j <=i)
                {
                    Console.Write(j + " ");
                    j++;
                 
                }
                Console.WriteLine();
                i++;
            }
           
            Console.Read();
        }
    }
}
